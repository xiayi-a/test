package net.mcreator.test.procedure;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import net.mcreator.test.ElementsTestMod;

import java.util.Map;

@ElementsTestMod.ModElement.Tag
public class ProcedureChunMingWuDi extends ElementsTestMod.ModElement {
	public ProcedureChunMingWuDi(ElementsTestMod instance) {
		super(instance, 2);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure ChunMingWuDi!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((entity instanceof EntityVillager)) {
			if ((!(entity.getEntityData().getBoolean("\u52A0\u8F7D2")))) {
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).heal((float) 1721);
			}
			if ((!(entity.getEntityData().getBoolean("\u52A0\u8F7D3")))) {
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).heal((float) 1721);
			}
		}
	}

	@SubscribeEvent
	public void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			Entity entity = event.getEntity();
			int i = (int) entity.posX;
			int j = (int) entity.posY;
			int k = (int) entity.posZ;
			World world = entity.world;
			java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
			dependencies.put("x", i);
			dependencies.put("y", j);
			dependencies.put("z", k);
			dependencies.put("world", world);
			dependencies.put("entity", entity);
			dependencies.put("event", event);
			dependencies.put("sourceentity", event.getSource().getImmediateSource());
			this.executeProcedure(dependencies);
		}
	}

	@Override
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);
	}
}
