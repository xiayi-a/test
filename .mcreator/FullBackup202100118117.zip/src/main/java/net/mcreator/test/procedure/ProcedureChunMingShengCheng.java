package net.mcreator.test.procedure;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSender;

import net.mcreator.test.ElementsTestMod;

import java.util.Random;
import java.util.Map;

@ElementsTestMod.ModElement.Tag
public class ProcedureChunMingShengCheng extends ElementsTestMod.ModElement {
	public ProcedureChunMingShengCheng(ElementsTestMod instance) {
		super(instance, 1);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure ChunMingShengCheng!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure ChunMingShengCheng!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure ChunMingShengCheng!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure ChunMingShengCheng!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure ChunMingShengCheng!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		if ((entity instanceof EntityVillager)) {
			if (((!(((entity.getDisplayName().getUnformattedText())).equals("\u70BC\u5668\u5E08")))
					&& ((entity.getEntityData().getBoolean("\u52A0\u8F7D2")) == (false)))) {
				entity.getEntityData().setBoolean("\u52A0\u8F7D2", (true));
				if ((Math.random() < 0.2)) {
					if (!world.isRemote && world.getMinecraftServer() != null) {
						world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return world;
							}

							@Override
							public MinecraftServer getServer() {
								return world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return new BlockPos((int) x, (int) y, (int) z);
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(x, y, z);
							}
						}, (("summon minecraft:villager ~ ~1 ~ {CustomName:\"\u70BC\u5668\u5E08\",Health:17210,Attributes:[{Name:\"generic.maxHealth\",Base:17210}],Offers:{Recipes:[{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 13 + 1)) + 15)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cai_liao_02\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 6 + 1)) + 7)))) + ""
								+ ("b,Damage:0s},sell:{id:\"fabaokuozhan:po_shan\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 13 + 1)) + 13)))) + ""
								+ ("b,Damage:0s},sell:{id:\"fabaokuozhan:cailiao13\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 8 + 1)) + 37)))) + ""
								+ ("b,Damage:0s},sell:{id:\"fabaokuozhan:cailiao15\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 2 + 1)) + 1)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuxiuzhen:ming_fu_ling_fang\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 3 + 1)) + 3)))) + ""
								+ ("b,Damage:0s},sell:{id:\"fabaokuozhan:cailiao19\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 3 + 1)) + 3)))) + ""
								+ ("b,Damage:0s},sell:{id:\"fabaokuozhan:cailiao18\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 3 + 1)) + 2)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuxiuzhen:tian_gong_ling_fang\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:gold_sword\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:wood_sword\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:water_sword\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:fire_sword\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:soil_sword\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:leaf\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:gourd\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 5)))) + ""
								+ ("b,Damage:0s},sell:{id:\"flyinginstrument:boat\",Count:1b,Damage:0s}}]}}")));
					}
					if (dependencies.get("event") != null) {
						Object _obj = dependencies.get("event");
						if (_obj instanceof net.minecraftforge.fml.common.eventhandler.Event) {
							net.minecraftforge.fml.common.eventhandler.Event _evt = (net.minecraftforge.fml.common.eventhandler.Event) _obj;
							if (_evt.isCancelable())
								_evt.setCanceled(true);
						}
					}
				}
			}
			if (((!(((entity.getDisplayName().getUnformattedText())).equals("\u70BC\u4E39\u5E08")))
					&& ((entity.getEntityData().getBoolean("\u52A0\u8F7D3")) == (false)))) {
				entity.getEntityData().setBoolean("\u52A0\u8F7D3", (true));
				if ((Math.random() < 0.2)) {
					if (!world.isRemote && world.getMinecraftServer() != null) {
						world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return world;
							}

							@Override
							public MinecraftServer getServer() {
								return world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return new BlockPos((int) x, (int) y, (int) z);
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(x, y, z);
							}
						}, (("summon minecraft:villager ~ ~1 ~ {CustomName:\"\u70BC\u4E39\u5E08\",Health:17210,Attributes:[{Name:\"generic.maxHealth\",Base:17210}],Offers:{Recipes:[{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 2 + 1)) + 1)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cao_yao_32\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 3 + 1)) + 4)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cao_yao_33\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 18 + 1)) + 21)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cai_liao_05\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 24 + 1)) + 40)))) + ""
								+ ("b,Damage:0s},buyB:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:") + ""
								+ ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 2 + 1)) + 1)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cai_liao_08\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 4 + 1)) + 3)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cai_liao_11\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 2 + 1)) + 1)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:caoyao18\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 9 + 1)) + 4)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:caoyao_1801\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 9 + 1)) + 4)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:caoyao_1802\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 3 + 1)) + 1)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:caoyao3\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 12 + 1)) + 7)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cao_yao_201\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi05\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 2 + 1)) + 1)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cao_yao_202\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 4 + 1)) + 2)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:caoyao25\",Count:1b,Damage:0s}},{uses:0,buy:{id:\"yvanchuxiuzhen:cailiaolingshi03\",Count:")
								+ "" + ((new java.text.DecimalFormat("0").format((((new Random()).nextInt((int) 16 + 1)) + 17)))) + ""
								+ ("b,Damage:0s},sell:{id:\"yvanchuliandan:cao_yao_601\",Count:1b,Damage:0s}}]}}")));
					}
					if (dependencies.get("event") != null) {
						Object _obj = dependencies.get("event");
						if (_obj instanceof net.minecraftforge.fml.common.eventhandler.Event) {
							net.minecraftforge.fml.common.eventhandler.Event _evt = (net.minecraftforge.fml.common.eventhandler.Event) _obj;
							if (_evt.isCancelable())
								_evt.setCanceled(true);
						}
					}
				}
			}
		}
	}

	@SubscribeEvent
	public void onEntitySpawned(EntityJoinWorldEvent event) {
		Entity entity = event.getEntity();
		int i = (int) entity.posX;
		int j = (int) entity.posY;
		int k = (int) entity.posZ;
		World world = event.getWorld();
		java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
		dependencies.put("x", i);
		dependencies.put("y", j);
		dependencies.put("z", k);
		dependencies.put("world", world);
		dependencies.put("entity", entity);
		dependencies.put("event", event);
		this.executeProcedure(dependencies);
	}

	@Override
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);
	}
}
